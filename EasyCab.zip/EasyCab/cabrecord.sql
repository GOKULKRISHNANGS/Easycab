create schema easycab;
set schema easycab;


--Login table
create table t_easycab_loginCredentials(userid varchar(40) primary key, password varchar(15), accounttype varchar(10));
drop table t_easycab_loginCredentials;

select * from t_easycab_loginCredentials







--Employee Details Table
create table t_easycab_employeedetails(userid varchar(40) REFERENCES t_easycab_logincredentials(userid), 
employee_name varchar(40),  employee_department varchar(20), 
employee_phonenumber varchar(15), employee_emailid varchar(30), 
employee_current_location varchar(30), employee_default_destination varchar(30),
employee_reporting_manager varchar(40));

drop table t_easycab_employeedetails;
select * from t_easycab_employeedetails;

select * from t_easycab_employeedetails

insert into t_easycab_loginCredentials values('XBBNHGK','XBBNHGK','EMPLOYEE')

insert into t_easycab_employeedetails values('XBBNHGK','MITHUN','L & D','8870300800','mmuraleedharan@inautix.co.in','Ascendas','bharathi nagar','devika rani');






--EmployeeBooking
create table t_easycab_bookinghistory(bookingid varchar(10) primary key, 
userid varchar(40) REFERENCES t_easycab_loginCredentials(userid), 
bookingdate date, 
employeelocation varchar(30));

insert into t_easycab_bookinghistory values('1004321', 'XBBNHGK', '2017-07-12', 'Taramani');
select * from t_easycab_bookinghistory;

drop table t_easycab_bookinghistory;

--Cab Details
create table t_easycab_�abdetails(companyname varchar(20), userid varchar(40) primary key, drivername varchar(40), phonenumber varchar(15));
drop table t_easycab_�abdetails;

insert into t_easycab_�abdetails values('Safe Drop', 'CAB234', 'Ravi', '9956645417');

create table t_easycab_bookingstatus(bookingid varchar(10) references t_easycab_bookinghistory(bookingid), 
bookingstatus varchar(20));

insert into t_easycab_bookingstatus values('1004321', 'confirmed');

drop table t_easycab_bookingstatus;



create table t_easycab_employeedetails(userid varchar(40) REFERENCES t_easycab_loginCredentials(userid), 
employee_name varchar(40),  
employee_department varchar(20), 
employee_phonenumber varchar(15), 
employee_emailid varchar(30), 
employee_current_location varchar(30),
employee_default_destination varchar(30), 
currentdate date,
employee_reporting_manager varchar(40));


