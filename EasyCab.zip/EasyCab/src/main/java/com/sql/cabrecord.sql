create schema easycab;
set schema easycab;

create table t_easycab_loginCredentials(userid varchar(40) primary key, password varchar(15), accounttype varchar(10));

create table t_easycab_employeedetails(userid varchar(40) REFERENCES t_easycab_loginCredentials(userid), employeelocation varchar(30), department varchar(20), phonenumber varchar(15), reportingmanager varchar(40));
select * from t_easycab_employeedetails

insert into 

create table t_easycab_bookinghistory(bookingid varchar(10) primary key, userid varchar(40) REFERENCES t_easycab_loginCredentials(userid), bookingdate date, employeelocation varchar(30));

create table t_easycab_�abdetails(companyname varchar(20), userid varchar(40) primary key, drivername varchar(40), phonenumber varchar(15));

drop table t_easycab_�abdetails;

create table t_easycab_bookingstatus(bookingid varchar(10) references t_easycab_bookinghistory(bookingid), bookingstatus varchar(20));

