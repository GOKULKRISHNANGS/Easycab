package com.hackathon.login;

import io.swagger.annotations.ApiModelProperty;

public class LoginBean {

	@ApiModelProperty(position = 1, required = true, value = "contains the userId(comitId)")
	private String userId;
	@ApiModelProperty(position = 2, required = true, value = "contains the password")
	private String password;
	@ApiModelProperty(position = 3, required = true, value = "contains the login type")
	private String loginType;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	
	
	
	
	
}
