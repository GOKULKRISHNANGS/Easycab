package com.hackathon.login;

public class LoginDao {

}
