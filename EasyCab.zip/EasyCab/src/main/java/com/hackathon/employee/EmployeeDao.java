package com.hackathon.employee;

import java.util.LinkedList;

public class EmployeeDao {
	
	public EmployeeDao()
	{
		
	}

	public LinkedList<EmployeeBean> getAllEmployees() {
		
		return null;		
	}
	
	

}
