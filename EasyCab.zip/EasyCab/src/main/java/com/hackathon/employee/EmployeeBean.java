package com.hackathon.employee;

import io.swagger.annotations.ApiModelProperty;

public class EmployeeBean {
	@ApiModelProperty(position = 1, required = true, value = "contains the userId(comitId)")
	private String userId;
	@ApiModelProperty(position = 2, required = true, value = "contains the employee name")
	private String employeeName;
	@ApiModelProperty(position = 3, required = true, value = "contains the department of the employee")
	private String department;
	@ApiModelProperty(position = 4, required = true, value = "contains the phone number")
	private String phoneNumber;
	@ApiModelProperty(position = 5, required = true, value = "contains the emailId")
	private String emailId;
	@ApiModelProperty(position = 6, required = true, value = "contains the default destination or permanent address")
	private String currentLocation;
	@ApiModelProperty(position = 7, required = true, value = "contains the default destination or permanent address")
	private String destination;
	@ApiModelProperty(position = 8, required = true, value = "contains the name of the manager that the employee reports")
	private String reportingManager;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getReportingManager() {
		return reportingManager;
	}

	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

}
