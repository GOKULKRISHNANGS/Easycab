package com.hackathon.employee;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeRowMapper implements RowMapper<EmployeeBean>{

	public EmployeeBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		EmployeeBean employeeBean = new EmployeeBean();
		employeeBean.setUserId(rs.getString(1));
		employeeBean.setEmployeeName(rs.getString(2));
		employeeBean.setDepartment(rs.getString(3));
		employeeBean.setPhoneNumber(rs.getString(4));
		employeeBean.setEmailId(rs.getString(5));
		employeeBean.setCurrentLocation(rs.getString(6));
		employeeBean.setDestination(rs.getString(7));
		employeeBean.setReportingManager(rs.getString(8));
		return employeeBean;
	}

}
