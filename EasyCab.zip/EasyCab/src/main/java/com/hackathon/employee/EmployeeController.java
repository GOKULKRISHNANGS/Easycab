package com.hackathon.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.helpdesk.HelpDeskBean;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@RestController
public class EmployeeController {

	@Autowired
	EmployeeDao employeeDao;

	@Autowired
	HelpDeskBean helpDeskBean;

	@RequestMapping(value = "/employees", method = RequestMethod.GET)
	public List<EmployeeBean> getAllEmployees() {
		employeeDao.getAllEmployees();
		return null;
	}


}
