package com.hackathon.model;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.hackathon.booking.StatusBean;
import com.hackathon.employee.EmployeeBean;
import com.hackathon.helpdesk.HelpDeskBean;

public class Data {

	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<HelpDeskBean> helpDeskBeanList;

	public List<HelpDeskBean> getHelpDeskBeanList() {
		return helpDeskBeanList;
	}

	public void setHelpDeskBeanList(List<HelpDeskBean> helpDeskBeanList) {
		this.helpDeskBeanList = helpDeskBeanList;
	}

	@ApiModelProperty(position = 2, required = false, value = "brief description of the property :output ")
	private List<EmployeeBean> employeeBean;

	public List<EmployeeBean> getEmployeeBean() {
		return employeeBean;
	}

	public void setEmployeeBean(List<EmployeeBean> employeeBean) {
		this.employeeBean = employeeBean;
	}

	@ApiModelProperty(position = 3, required = true, value = "brief description of the property :output ")
	private List<StatusBean> statusBean;

	public List<StatusBean> getStatusBean() {
		return statusBean;
	}

	public void setStatusBean(List<StatusBean> statusBean) {
		this.statusBean = statusBean;
	}

}
