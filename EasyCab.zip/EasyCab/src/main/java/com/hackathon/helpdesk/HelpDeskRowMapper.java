package com.hackathon.helpdesk;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class HelpDeskRowMapper implements RowMapper<HelpDeskBean> {

	public HelpDeskBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		HelpDeskBean helpDeskBean = new HelpDeskBean();
		helpDeskBean.setBookingId(rs.getString(1));
		helpDeskBean.setEmployeeId(rs.getString(2));
		System.out.println(rs.getString(2));
		System.out.println(rs.getDate(3));
		helpDeskBean.setPickupTime(rs.getDate(3));
		helpDeskBean.setDestination(rs.getString(4));
		return helpDeskBean;
	}

}
