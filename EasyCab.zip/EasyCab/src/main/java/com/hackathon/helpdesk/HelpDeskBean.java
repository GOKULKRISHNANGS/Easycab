package com.hackathon.helpdesk;

import java.sql.Date;

import io.swagger.annotations.ApiModelProperty;

public class HelpDeskBean {

	@ApiModelProperty(position = 1, required = true, value = "contains the bookingId")
	private String bookingId;
	@ApiModelProperty(position = 2, required = true, value = "contains the userId")
	private String employeeId;
	@ApiModelProperty(position = 3, required = true, value = "contains the dateId")
	private Date pickupTime;
	@ApiModelProperty(position = 4, required = true, value = "contains the location")
	private String destination;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getPickupTime() {
		return pickupTime;
	}

	public void setPickupTime(Date pickupTime) {
		this.pickupTime = pickupTime;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

}
