package com.hackathon.helpdesk;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.booking.StatusBean;
import com.hackathon.model.Data;
import com.hackathon.model.ErrorDetails;
import com.hackathon.model.MetaData;
import com.hackathon.model.Response;

@RestController
public class HelpDeskController {

	@Autowired
	HelpDeskDao helpDeskDao;

	@Autowired
	Data data;

	@Autowired
	MetaData metaData;

	@Autowired
	ErrorDetails errorDetails;

	@Autowired
	Response response;

	@ApiOperation(value = "retrieve all book record using GET method", notes = "Returns the book data of all books.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of employee details", response = Response.class),
			@ApiResponse(code = 404, message = "employee with given employeeid does not exist", response = Response.class),
			@ApiResponse(code = 400, message = "employee with employeeid does not exist", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
	@RequestMapping(value = "/bookings", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Response> getBookings() {
		List<HelpDeskBean> bookingList = helpDeskDao.getAllBookings();
		ResponseEntity<Response> responseEntity = null;
		try {
			if (bookingList.isEmpty()) {
				throw new NullPointerException();
			} else {
				data.setHelpDeskBeanList(bookingList);
				saveErrorDetails(null, null);
				saveMetaData(true, "Success", "200");
				saveResponse(data, metaData, errorDetails);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			data.setHelpDeskBeanList(null);
			saveErrorDetails("404", "Not Found");
			saveMetaData(true, "No Bookings till now", "404");
			saveResponse(data, metaData, errorDetails);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

	@ApiOperation(value = "retrieve all book record using GET method", notes = "Returns the book data of all books.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of employee details", response = Response.class),
			@ApiResponse(code = 404, message = "employee with given employeeid does not exist", response = Response.class),
			@ApiResponse(code = 400, message = "employee with employeeid does not exist", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
	@RequestMapping(value = "/status", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Response> getStatus() {
		List<StatusBean> bookingList = helpDeskDao.getStatus();
		ResponseEntity<Response> responseEntity = null;
		try {
			if (bookingList.isEmpty()) {
				throw new NullPointerException();
			} else {
				data.setStatusBean(bookingList);
				saveErrorDetails(null, null);
				saveMetaData(true, "Success", "200");
				saveResponse(data, metaData, errorDetails);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			saveErrorDetails("404", "Not Found");
			saveMetaData(true, "No Bookings till now", "404");
			saveResponse(data, metaData, errorDetails);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);
		}
		return responseEntity;

	}

	private void saveMetaData(boolean b, String description, String responseId) {
		metaData.setSuccess(b);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}

	private void saveErrorDetails(String code, String description) {
		errorDetails.setCode(code);
		errorDetails.setDescription(description);
	}

	private void saveResponse(Data data, MetaData metaData,
			ErrorDetails errorDetails) {
		response.setData(data);
		response.setError(errorDetails);
		response.setMetaData(metaData);
	}

	@ExceptionHandler(TypeMismatchException.class)
	public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(
			TypeMismatchException exception, HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA100");
		error.setDescription("Type mismatch exception. Please enter only numbers in bookId");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);
		return responseEntity;
	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(
			Exception exception, HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA1004");
		error.setDescription("Bad Request");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);
		return responseEntity;
	}

}
