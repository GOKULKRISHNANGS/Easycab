package com.hackathon.helpdesk;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.booking.StatusBean;
import com.hackathon.booking.StatusRowMapper;
import com.hackathon.employee.EmployeeBean;
import com.hackathon.employee.EmployeeRowMapper;

@Component
public class HelpDeskDao extends JdbcDaoSupport {

	@Autowired
	public HelpDeskDao(DataSource dataSource) {
		setDataSource(dataSource);
	}

	public List<EmployeeBean> getAllEmployees() {
		List<EmployeeBean> employeeList = null;
		employeeList = getJdbcTemplate().query(
				"select * from t_easycab_employeedetails",
				new EmployeeRowMapper());
		return employeeList;
	}

	public List<HelpDeskBean> getAllBookings() {
		List<HelpDeskBean> helpDeskList = null;
		helpDeskList = getJdbcTemplate().query(
				"select * from t_easycab_bookinghistory",
				new HelpDeskRowMapper());
		return helpDeskList;
	}

	public List<StatusBean> getStatus() {
		List<StatusBean> statusList = null;
		statusList = getJdbcTemplate().query(
				"select * from t_easycab_bookingstatus", new StatusRowMapper());
		return statusList;
	}

}
