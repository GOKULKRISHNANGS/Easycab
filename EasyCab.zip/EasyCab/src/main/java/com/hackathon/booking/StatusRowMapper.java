package com.hackathon.booking;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StatusRowMapper implements RowMapper<StatusBean> {

	public StatusBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		StatusBean statusBean = new StatusBean();
		statusBean.setBookingId(rs.getString(1));
		statusBean.setStatus(rs.getString(2));
		return statusBean;
	}

}
