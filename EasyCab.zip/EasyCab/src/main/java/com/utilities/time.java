package com.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class time {
	
	public static void main(String args[])
	{
		Scanner scn = new Scanner(System.in);
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = sdf.format(date);
		System.out.println(formattedDate);
		int choice = scn.nextInt();
		String result = formattedDate;
		switch (choice) {
		case 1:
			result = result + " 10 PM";
			break;

		case 2:
			result = result + " 11 PM";
			break;
			
		default:
			break;
		}
		
		System.out.println(result);
        
	}

}
