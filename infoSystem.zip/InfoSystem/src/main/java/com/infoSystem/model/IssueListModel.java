package com.infoSystem.model;

import java.util.List;

public class IssueListModel {

	private List<IssueModel> issueList;

	public List<IssueModel> getIssueList() {
		return issueList;
	}

	public void setIssueList(List<IssueModel> issueList) {
		this.issueList = issueList;
	}

}
