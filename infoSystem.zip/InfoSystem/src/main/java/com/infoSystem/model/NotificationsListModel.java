package com.infoSystem.model;

import java.util.List;

public class NotificationsListModel {

	public List<NotificationModel> notificationList;

	public List<NotificationModel> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<NotificationModel> notificationList) {
		this.notificationList = notificationList;
	}

}
